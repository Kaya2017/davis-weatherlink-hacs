"""Read Davis observations from the WeatherLink v2 cloud API."""
from math import isfinite

from aiohttp import ClientError, ClientTimeout

DOMAIN = "davis_weatherlink"
OUTDOOR_TYPES = {1, 2, 6, 10, 23}
PRESSURE_TYPES = {1, 2, 12, 19}


class WeatherLinkError(Exception):
    """WeatherLink request or response failed."""


class WeatherLinkAuthError(WeatherLinkError):
    """WeatherLink rejected the credentials."""


class WeatherLinkStationError(WeatherLinkError):
    """No usable observations were returned for the station."""


class WeatherLinkClient:
    def __init__(self, session, key, secret):
        self.session = session
        self.key = key
        self.secret = secret

    async def get(self, path):
        try:
            async with self.session.get(
                f"https://api.weatherlink.com/v2/{path}",
                params={"api-key": self.key},
                headers={"X-Api-Secret": self.secret},
                timeout=ClientTimeout(total=15),
                allow_redirects=False,
                raise_for_status=False,
            ) as response:
                if response.status in {401, 403}:
                    raise WeatherLinkAuthError("Zugriff verweigert")
                if response.status == 404:
                    raise WeatherLinkStationError("Station nicht gefunden")
                if response.status != 200:
                    raise WeatherLinkError(f"WeatherLink meldet HTTP {response.status}")
                payload = await response.json()
        except (ClientError, TimeoutError, ValueError, UnicodeError):
            raise WeatherLinkError("WeatherLink nicht erreichbar oder Antwort ungültig") from None
        if not isinstance(payload, dict):
            raise WeatherLinkError("Ungültige WeatherLink-Antwort")
        return payload

    async def current(self, station_id):
        return observations(await self.get(f"current/{station_id}"))


def number(value):
    if isinstance(value, bool):
        return None
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return converted if isfinite(converted) else None


def observations(payload):
    """Find the newest numeric value for each measurement in the current feed."""
    def read(types, fields):
        records = (
            record
            for sensor in payload.get("sensors") or []
            if isinstance(sensor, dict) and sensor.get("data_structure_type") in types
            for record in sensor.get("data") or []
            if isinstance(record, dict)
        )
        for record in sorted(records, key=lambda item: number(item.get("ts")) or 0, reverse=True):
            for field, factor, offset in fields:
                value = number(record.get(field))
                if value is not None:
                    return round((value + offset) * factor, 2)
        return None

    def outdoor(*keys, factor=1, offset=0):
        return read(OUTDOOR_TYPES, [(key, factor, offset) for key in keys])

    values = {
        "temperature": outdoor("temp", "temp_out", factor=5 / 9, offset=-32),
        "humidity": outdoor("hum", "hum_out"),
        "dew_point": outdoor("dew_point", factor=5 / 9, offset=-32),
        "pressure": read(PRESSURE_TYPES, [(key, 33.8638867, 0) for key in ("bar_sea_level", "bar")]),
        "wind_speed": outdoor("wind_speed_last", "wind_speed", factor=1.609344),
        "wind_direction": outdoor("wind_dir_last", "wind_dir"),
        "rain_today": read(OUTDOOR_TYPES, [
            ("rain_day_mm", 1, 0), ("rainfall_daily_mm", 1, 0),
            ("rainfall_daily_in", 25.4, 0),
        ]),
        "solar": outdoor("solar_rad", "solar"),
        "uv": outdoor("uv_index", "uv"),
    }
    if all(value is None for value in values.values()):
        raise WeatherLinkStationError("Keine unterstützten Messwerte verfügbar")
    return values

"""Home Assistant sensor entities for the Davis weather station."""
from homeassistant.components.sensor import (
    SensorDeviceClass as DeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass as StateClass,
)
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .api import DOMAIN

SENSORS = (
    ("temperature", DeviceClass.TEMPERATURE, "°C"),
    ("humidity", DeviceClass.HUMIDITY, "%"),
    ("dew_point", DeviceClass.TEMPERATURE, "°C"),
    ("pressure", DeviceClass.ATMOSPHERIC_PRESSURE, "hPa"),
    ("wind_speed", DeviceClass.WIND_SPEED, "km/h"),
    ("wind_direction", None, "°"),
    ("rain_today", DeviceClass.PRECIPITATION, "mm"),
    ("solar", DeviceClass.IRRADIANCE, "W/m²"),
    ("uv", None, None),
)

DESCRIPTIONS = tuple(
    SensorEntityDescription(
        key=key, translation_key=key, device_class=device_class,
        native_unit_of_measurement=unit,
        state_class=None if key in {"rain_today", "wind_direction"} else StateClass.MEASUREMENT,
        entity_registry_enabled_default=key != "uv",
    )
    for key, device_class, unit in SENSORS
)


async def async_setup_entry(hass, entry, async_add_entities):
    async_add_entities(DavisSensor(entry, description) for description in DESCRIPTIONS)


class DavisSensor(CoordinatorEntity, SensorEntity):
    _attr_has_entity_name = True

    def __init__(self, entry, description):
        super().__init__(entry.runtime_data)
        self.entity_description = description
        station_id = entry.data["station_id"]
        self._attr_unique_id = f"{station_id}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, station_id)}, manufacturer="Davis Instruments",
            model="Vantage Pro2", name=entry.title,
        )

    @property
    def native_value(self):
        return self.coordinator.data[self.entity_description.key]

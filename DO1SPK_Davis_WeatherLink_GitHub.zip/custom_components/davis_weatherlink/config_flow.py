"""Set up a station using the WeatherLink account station list."""
import voluptuous as vol

from homeassistant.config_entries import ConfigFlow
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.selector import TextSelector, TextSelectorConfig, TextSelectorType

from .api import DOMAIN, WeatherLinkAuthError, WeatherLinkClient, WeatherLinkError, WeatherLinkStationError


class WeatherLinkConfigFlow(ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(self, user_input=None):
        errors = {}
        if user_input is not None:
            self.credentials = {key: value.strip() for key, value in user_input.items()}
            self.client = WeatherLinkClient(
                async_get_clientsession(self.hass),
                self.credentials["api_key"], self.credentials["api_secret"],
            )
            try:
                result = await self.client.get("stations")
            except WeatherLinkAuthError:
                errors["base"] = "invalid_auth"
            except WeatherLinkError:
                errors["base"] = "cannot_connect"
            else:
                self.stations = {
                    str(station["station_id"]): station.get("station_name") or "Davis Vantage Pro2"
                    for station in result.get("stations") or []
                    if isinstance(station, dict) and station.get("station_id") is not None
                }
                if self.stations:
                    return await self.async_step_station()
                errors["base"] = "no_stations"
        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema({
                vol.Required("api_key"): TextSelector(),
                vol.Required("api_secret"): TextSelector(
                    TextSelectorConfig(type=TextSelectorType.PASSWORD)
                ),
            }),
            errors=errors,
        )

    async def async_step_station(self, user_input=None):
        errors = {}
        if user_input is not None:
            station_id = user_input["station_id"]
            await self.async_set_unique_id(station_id)
            self._abort_if_unique_id_configured()
            try:
                await self.client.current(station_id)
            except WeatherLinkAuthError:
                errors["base"] = "invalid_auth"
            except WeatherLinkStationError:
                errors["base"] = "no_observations"
            except WeatherLinkError:
                errors["base"] = "cannot_connect"
            else:
                return self.async_create_entry(
                    title=self.stations[station_id],
                    data={**self.credentials, "station_id": station_id},
                )
        return self.async_show_form(
            step_id="station",
            data_schema=vol.Schema({
                vol.Required("station_id", default=next(iter(self.stations))): vol.In({
                    identifier: f"{name} ({identifier})"
                    for identifier, name in self.stations.items()
                }),
            }),
            errors=errors,
        )

"""Davis Vantage Pro2 through WeatherLink cloud."""
from datetime import timedelta
import logging

from homeassistant.const import Platform
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import WeatherLinkClient, WeatherLinkError

PLATFORMS = [Platform.SENSOR]


async def async_setup_entry(hass, entry):
    client = WeatherLinkClient(
        async_get_clientsession(hass), entry.data["api_key"], entry.data["api_secret"]
    )

    async def update():
        try:
            return await client.current(entry.data["station_id"])
        except WeatherLinkError as err:
            raise UpdateFailed(str(err)) from None

    coordinator = DataUpdateCoordinator(
        hass, logger=logging.getLogger(__name__),
        config_entry=entry, name="WeatherLink", update_interval=timedelta(minutes=5),
        update_method=update, always_update=False,
    )
    await coordinator.async_config_entry_first_refresh()
    entry.runtime_data = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass, entry):
    return await hass.config_entries.async_unload_platforms(entry, PLATFORMS)

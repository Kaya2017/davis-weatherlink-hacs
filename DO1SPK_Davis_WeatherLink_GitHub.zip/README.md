# Davis Vantage Pro2 – WeatherLink für Home Assistant

Version 0.1.0 · vorgesehen für Home Assistant Core ab 2025.1

Die Integration liest aktuelle Messwerte über die WeatherLink-v2-Cloud-API.
Home Assistant fragt die Station alle fünf Minuten mit einem gemeinsamen
Request für alle Sensoren ab. Ein WeatherLink-Konto mit Zugriff auf die
aktuellen Stationsdaten ist erforderlich.

## Installation direkt aus der ZIP

1. ZIP entpacken und den Ordner `davis_weatherlink` aus `custom_components`
   nach `/config/custom_components/` kopieren. Die Datei `manifest.json`
   muss unter `/config/custom_components/davis_weatherlink/manifest.json` liegen.
2. Home Assistant neu starten.
3. **Einstellungen → Geräte & Dienste → Integration hinzufügen** öffnen
   und nach **Davis Vantage Pro2 – WeatherLink** suchen.
4. Den vorhandenen WeatherLink **API Key** und das **API Secret** eingeben.
   Anschließend die Station aus der Liste auswählen.

Die Zugangsdaten findest du bei [WeatherLink unter Account](https://www.weatherlink.com/account).
Verwende die bereits vorhandenen v2-Zugangsdaten, falls du sie auch für
deine Wettergrafik nutzt. Das Erzeugen eines neuen v2-Secrets macht das
bisherige Secret ungültig. Die Integration braucht keinen YAML-Eintrag.

Falls das bisherige REST-Paket bereits aktiv ist, prüfe nach der Einrichtung
die neuen Sensoren und weise sie bei Bedarf deinen Dashboard-Karten und
Automationen zu, bevor du die alte Abfrage deaktivierst. Die neuen Sensoren
erhalten eigene Entitäts-IDs.

## Über HACS installieren

1. In HACS **⋮ → Benutzerdefinierte Repositories** öffnen.
2. `https://github.com/Kaya2017/davis-weatherlink-hacs` eintragen,
   die Kategorie **Integration** wählen und das Repository hinzufügen.
3. **Davis Vantage Pro2 – WeatherLink** in HACS herunterladen und Home
   Assistant neu starten.
4. In **Einstellungen → Geräte & Dienste → Integration hinzufügen**
   die Integration wählen, die v2-Zugangsdaten eingeben und die Station auswählen.

[HACS-Dokumentation zu eigenen Repositories](https://hacs.dev/docs/faq/custom_repositories/)

## Messwerte

| Sensor | Einheit |
| --- | --- |
| Außentemperatur und Taupunkt | °C |
| Außenluftfeuchtigkeit | % |
| Luftdruck | hPa |
| Windgeschwindigkeit | km/h |
| Windrichtung | ° |
| Regen heute | mm |
| Sonneneinstrahlung | W/m² |
| UV-Index | ohne Einheit, standardmäßig deaktiviert |

Optionale Werte wie Sonneneinstrahlung setzen passende Sensorhardware
und entsprechende Daten in WeatherLink voraus. Fehlende Messwerte
erscheinen als unbekannt. Bei einem fehlgeschlagenen Abruf meldet
Home Assistant die Sensoren als nicht verfügbar und versucht den Abruf
beim nächsten Intervall erneut.
